# Homework 5 Videos

## Camera Calibration
[https://drive.google.com/file/d/11MKJfVxZ20SPf79CK3njWOBl3hld7Hci/view?usp=drive_link](https://drive.google.com/file/d/11MKJfVxZ20SPf79CK3njWOBl3hld7Hci/view?usp=drive_link)

## Guggenheim Raw Video
[https://drive.google.com/file/d/1-0LHu7Gawxo5Fbc4fk4TAkg5776Jvn_l/view?usp=drive_link](https://drive.google.com/file/d/1-0LHu7Gawxo5Fbc4fk4TAkg5776Jvn_l/view?usp=drive_link)

## Guggenheim OSLAM
[https://drive.google.com/file/d/15LQ9Dv197Ije-DCFtzYrxtva-zJhtjy8/view?usp=sharing](https://drive.google.com/file/d/15LQ9Dv197Ije-DCFtzYrxtva-zJhtjy8/view?usp=sharing)